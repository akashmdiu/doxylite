<?php 
/**
 * Silence is golden
 */